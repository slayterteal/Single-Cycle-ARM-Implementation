** Slayter Teal and Daniel Albrecht**

The Command (cmd) to execute the code is: 

> vsim -do arm_single.do

The command the run the python script is:

Windows:
> python arm3hex arm-none-eabi-as memfile.s memfile.dat
